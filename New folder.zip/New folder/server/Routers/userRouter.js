import express, { Router } from "express";
import {
  Insert,
  login,
  userByEmail,
  userById,
  userData,
} from "../Controllers/userController.js";
import { auth } from "../Middleware/auth.js";

const router = express.Router();

router.get("/", (req, res) => {
  res.send("welcome to home page");
});

router.post("/user", Insert);

router.get("/user",auth,userData);

router.post("/login",  login);

router.get("/user/id/:id", userById);

router.get("/user/email/:email", userByEmail);

export default router;
