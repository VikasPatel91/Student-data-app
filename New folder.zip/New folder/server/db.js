import mongoose from "mongoose";

const db = mongoose.connect("mongodb://localhost/mydb");

db.then(() => {
  console.log("DataBase Connected");
});
db.catch(() => {
  console.log("Unable to Connect");
});

export default db;
