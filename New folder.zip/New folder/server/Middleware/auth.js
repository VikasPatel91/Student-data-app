import jwt from "jsonwebtoken";
import model from "../Models/userModel.js";

export async function auth(req,res,next) {
    try {
        const token=req.cookies.jwt
        const varifyUser=jwt.verify(token,24680)
       // console.log(varifyUser);

        const user= await model.findOne({_id:varifyUser._id})
        console.log(user);
        next()

    } catch (error) {
        res.status(400).json(error)
    }
}