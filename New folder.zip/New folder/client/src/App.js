import './App.css';
import { Routes, Route, BrowserRouter } from 'react-router-dom'
import NavigationBar from './component/Navbar';
import Home from './component/Home';
import Insert from './component/InsertStudent';
import StudentData from './component/StudentData';

function App() {
  return (
    <BrowserRouter>
      <NavigationBar></NavigationBar>
      <Routes>
        <Route path='/' element={<Home></Home>}></Route>
        <Route path='/Insert-Student' element={<Insert></Insert>}></Route>
        <Route path='/Student-Data' element={<StudentData></StudentData>}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
