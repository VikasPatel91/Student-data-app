const Home = () => {
  return <div>welcome to home page and the best page ever.</div>;
};

export default Home;
